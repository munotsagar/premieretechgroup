<?php
// created: 2013-11-20 07:40:07
$dictionary["tsc_SMS"]["fields"]["tsc_sms_tsc_sms_details"] = array (
  'name' => 'tsc_sms_tsc_sms_details',
  'type' => 'link',
  'relationship' => 'tsc_sms_tsc_sms_details',
  'source' => 'non-db',
  'module' => 'tsc_sms_details',
  'bean_name' => 'tsc_sms_details',
  'side' => 'right',
  'vname' => 'LBL_TSC_SMS_TSC_SMS_DETAILS_FROM_TSC_SMS_DETAILS_TITLE',
);
