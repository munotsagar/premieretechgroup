<?php
 // created: 2020-04-05 14:19:48
$dictionary['Account']['fields']['show_password_c']['inline_edit']='';
$dictionary['Account']['fields']['show_password_c']['labelValue']='show password';

 ?>