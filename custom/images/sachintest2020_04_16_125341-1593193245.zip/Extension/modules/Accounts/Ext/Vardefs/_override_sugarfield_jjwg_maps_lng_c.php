<?php
 // created: 2019-11-25 13:09:51
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>