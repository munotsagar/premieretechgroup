<?php 
 // created: 2020-04-16 12:53:32
$mod_strings['LBL_SHOW_PASSWORD'] = 'show password';

?>
