<?php 
 // created: 2020-04-16 12:53:27
$mod_strings['LBL_PandaDoc'] = 'Panda Doc';

?>
