<?php
require_once('include/MVC/Controller/SugarController.php');

class srav_Mapping_FunctionalityController extends SugarController {
    
	function action_modulelist(){
		$this->view = 'modulelist';
	}
	function action_mapvariables(){
		$this->view = 'mapvariables';
	}
	function action_transferdata(){
		$this->view = 'transferdata';
	}
}
?>