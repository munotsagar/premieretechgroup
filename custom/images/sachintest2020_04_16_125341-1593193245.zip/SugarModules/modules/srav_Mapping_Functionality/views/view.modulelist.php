<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class ViewModulelist extends ViewDetail {


	function ViewModulelist(){
		parent::ViewDetail();
	}
	
	function display() {
	$crm1url=$_REQUEST['crm1url'];
	$password1=$_REQUEST['password1'];
	$username1=$_REQUEST['username1'];
	$crm2url=$_REQUEST['crm2url'];
	$password2=$_REQUEST['password2'];
	$username2=$_REQUEST['username2'];
	//crm1 modules list
	$url1 = $crm1url."/service/v4_1/rest.php";
    //function to make cURL request
    function call($method, $parameters, $url1)
    {
        ob_start();
        $curl_request = curl_init();

        curl_setopt($curl_request, CURLOPT_URL, $url1);
        curl_setopt($curl_request, CURLOPT_POST, 1);
        curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($curl_request, CURLOPT_HEADER, 1);
        curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);

        $jsonEncodedData = json_encode($parameters);

        $post = array(
             "method" => $method,
             "input_type" => "JSON",
             "response_type" => "JSON",
             "rest_data" => $jsonEncodedData
        );

        curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
        $result = curl_exec($curl_request);
        curl_close($curl_request);

        $result = explode("\r\n\r\n", $result, 2);
        $response = json_decode($result[1]);
        ob_end_flush();

        return $response;
    }
    //login --------------------------------------------- 
    $login_parameters = array(
         "user_auth" => array(
              "user_name" => $username1,
              "password" => md5($password1),
              "version" => "1"
         ),
         "application_name" => "RestTest",
         "name_value_list" => array(),
    );

    $login_result = call("login", $login_parameters, $url1);

    //get session id
    $session_id = $login_result->id;
    //retrieve records -------------------------------------     
	$get_available_modules_parameters = array(
	    //Session id
	    "session" => $session_id,
	    "filter" => 'all',);


	$get_modules_result = call("get_available_modules", $get_available_modules_parameters, $url1);

	$modulename_crm1= array();
	$select1_module1='<select class="form-control" style="width:200px;" name="module1" required><option value="">--Select Module--</option>';

	foreach ($get_modules_result->modules as $data) { 
	    $modulename_crm1[]= $data->module_label."%-%".$data->module_key; 
	}
	foreach($modulename_crm1 as $value){
		$valuedata=explode('%-%',$value);
		if($valuedata['0'] !=""){
			$select1_module1.="<option value='$valuedata[1]'>$valuedata[0]</option>";
		}
	}
	$select1_module1.="</select>";
	//crm2 module list

	$url2 = $crm2url."/service/v4_1/rest.php";

    //function to make cURL request
    function call1($method, $parameters, $url2)
    {
        ob_start();
        $curl_request = curl_init();

        curl_setopt($curl_request, CURLOPT_URL, $url2);
        curl_setopt($curl_request, CURLOPT_POST, 1);
        curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($curl_request, CURLOPT_HEADER, 1);
        curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);

        $jsonEncodedData = json_encode($parameters);

        $post = array(
             "method" => $method,
             "input_type" => "JSON",
             "response_type" => "JSON",
             "rest_data" => $jsonEncodedData
        );

        curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
        $result = curl_exec($curl_request);
        curl_close($curl_request);

        $result = explode("\r\n\r\n", $result, 2);
        $response = json_decode($result[1]);
        ob_end_flush();

        return $response;
    }

    //login --------------------------------------------- 
    $login_parameters = array(
         "user_auth" => array(
              "user_name" => $username2,
              "password" => md5($password2),
              "version" => "1"
         ),
         "application_name" => "RestTest",
         "name_value_list" => array(),
    );

    $login_result = call("login", $login_parameters, $url2);

    //get session id
    $session_id = $login_result->id;
    //retrieve records -------------------------------------     
  $get_available_modules_parameters = array(
    //Session id
    "session" => $session_id,

    //Module filter. Possible values are 'default', 'mobile', 'all'.
    "filter" => 'all',);


    $get_modules_result = call1("get_available_modules", $get_available_modules_parameters, $url2);
/* echo '<pre>';
print_r($get_modules_result); */


 	$modulename_crm2= array();
  
	foreach ($get_modules_result->modules as $data) { 
	    $modulename_crm2[]= $data->module_label."%-%".$data->module_key; 
	}
	$select2_module2='<select class="form-control" style="width:200px;" name="module2" required><option value="">--Select Module--</option>';
	foreach($modulename_crm2 as $value){
		$valuedata=explode('%-%',$value);
		if($valuedata['0'] !=""){
			$select2_module2.="<option value='$valuedata[1]'>$valuedata[0]</option>";
		}
	}
	$select2_module2.="</select>";
	$js1 = <<<YUO
<html>
<head>
  	<script>
        $(document).ready(function(){
            $('#dialogSugar').hide();
            $('#dialogSuite').hide();
            
        })
    </script>
</head>
<body>
	<h2>Select Modules</h2>
	<div class="container" id="form-crm-details">
	    <div class="row">
	        <form action="index.php">
	            <div class="col-xs-6">
	                <div class="form-group">
	                	<div class="form-group">
	                    <label for="crm1url">CRM 1 URL</label>
	                    <input type="text" class="form-control" name="crm1url" id="crm1url" placeholder="From CRM URL" value="$crm1url" required readonly>
		                </div>
		                <div class="form-group">
		                    <label for="username1">CRM Username</label>
		                    <input type="text" class="form-control" name="username1" id="username1" placeholder="CRM Username" value="$username1" required readonly>
		                </div>
		                <div class="form-group">
		                    <label for="password">Password</label>
		                    <input type="password" class="form-control" name="password1" id="password1" placeholder="Password" value="$password1"  required readonly>
		                </div>
		                <div class="form-group">
	                    <label for="crm1modules">CRM 1 Modules List</label>
	                    $select1_module1
						</div>
	                </div>
	                <button type="submit" class="btn btn-default">Submit</button>
	            </div>
	            <div class="col-xs-6">
	                <div class="form-group">
	                	<div class="form-group">
	                    <label for="crm2url">CRM 2 URL</label>
	                    <input type="text" class="form-control" name="crm2url" id="crm2url" placeholder="To CRM URL" value="$crm2url"  required readonly>
		                </div>
		                <div class="form-group">
		                    <label for="username2">CRM Username</label>
		                    <input type="text" class="form-control" name="username2" id="username2" placeholder="CRM Username" value="$username2" required readonly>
		                </div>
		                <div class="form-group">
		                    <label for="password">Password</label>
		                    <input type="password" class="form-control" name="password2" id="password2" placeholder="Password" value="$password2" required readonly>
		                </div>
		                <div class="form-group">
	                    <label for="crm2modules">CRM 2 Modules List</label>
	                   	$select2_module2
						</div>
						<input type="text" class="form-control" name="module" id="size" placeholder="size" style="display:none" value="srav_Mapping_Functionality" required readonly>
	                  <input type="text" class="form-control" name="action" id="size" placeholder="size" style="display:none" value="mapvariables" required readonly>
	                    </div>
	                </div>
	            
	            </div>
	        </form>
	    </div>
	</div>
</body>
</html>

YUO;
echo $js1; 
	}

}

?>