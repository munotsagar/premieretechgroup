<?php


if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class ViewMapvariables extends ViewDetail {


	function ViewMapvariables(){
		parent::ViewDetail();
	}
	
	function display() {
		global $db,$sugar_config;
		$site_url=$sugar_config['site_url'];
		$url=$site_url."/index.php?module=srav_Mapping_Functionality";
		$crm1url=$_REQUEST['crm1url'];
		$password1=$_REQUEST['password1'];
		$username1=$_REQUEST['username1'];
		$module1=$_REQUEST['module1'];
		$crm2url=$_REQUEST['crm2url'];
		$password2=$_REQUEST['password2'];
		$username2=$_REQUEST['username2'];
		$module2=$_REQUEST['module2'];
		$for_back_button='';
	  //for mapping save functionality
	  if(!empty($_REQUEST['size'])){
	  	$for_back_button='<button type="button" id="back_transfer" class="btn btn-danger"> Back </button>';
	    $size = $_REQUEST['size'] - 1;
	    for ($i = 1; $i <= $size; $i++) {

	        if (!empty($_REQUEST["select2module$i"])) {
	            if ($_REQUEST["select2module$i"] != 'deleted') {
	                if($i=='2' && $module1=='Notes'){
	                    $j='0';
	                    $select_fields = $_REQUEST["select1module$j"];
	                    $id="select1module$j";
	                }
	                else{
	                    $select_fields = $_REQUEST["select1module$i"];
	                    $id="select1module$i";

	                }
	                //echo $id;
	                $set_fields    = $_REQUEST["select2module$i"];
	                $script_select.="$('#$id').val('$set_fields');";

	            }
	        }
	        
	    }
	  }

	  //end for mapping save functionality
		$url1 = $crm1url."/service/v4_1/rest.php";
	    //function to make cURL request
	    function call($method, $parameters, $url1)
	    {
	        ob_start();
	        $curl_request = curl_init();

	        curl_setopt($curl_request, CURLOPT_URL, $url1);
	        curl_setopt($curl_request, CURLOPT_POST, 1);
	        curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
	        curl_setopt($curl_request, CURLOPT_HEADER, 1);
	        curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
	        curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
	        curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);

	        $jsonEncodedData = json_encode($parameters);

	        $post = array(
	             "method" => $method,
	             "input_type" => "JSON",
	             "response_type" => "JSON",
	             "rest_data" => $jsonEncodedData
	        );

	        curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
	        $result = curl_exec($curl_request);
	        curl_close($curl_request);

	        $result = explode("\r\n\r\n", $result, 2);
	        $response = json_decode($result[1]);
	        ob_end_flush();

	        return $response;
	    }
	    //login --------------------------------------------- 
	    $login_parameters = array(
	         "user_auth" => array(
	              "user_name" => $username1,
	              "password" => md5($password1),
	              "version" => "1"
	         ),
	         "application_name" => "RestTest",
	         "name_value_list" => array(),
	    );

	    $login_result = call("login", $login_parameters, $url1);

	    //get session id
	    $session_id = $login_result->id;
	    $get_module_fields_parameters = array(
		    //Session id
		    "session" => $session_id,

		    //The name of the module from which to retrieve fields
		    'module_name' => $module1,

		    //List of specific fields
		    'fields' => array(),
		);

	    $get_module_fields_result = call("get_module_fields", $get_module_fields_parameters, $url1);
	    $modulefield= array();
		foreach($get_module_fields_result->module_fields as $data) { 
			$modulefield[]=$data->name;
		}
		$size_variables=sizeof($modulefield);
		$select_module1="";
		for($i=0;$i<$size_variables;$i++){
			$value=$modulefield[$i];
			if($value!='id'){
				$select_module1.="<div class='form-group'><input type='text' class='form-control' style='height:40px;' name=select1module$i id=$value value=$value required readonly></div>";
			}	
		}
		$url2 = $crm2url."/service/v4_1/rest.php";
	    //function to make cURL request
	    function call1($method, $parameters, $url2)
	    {
	        ob_start();
	        $curl_request = curl_init();

	        curl_setopt($curl_request, CURLOPT_URL, $url2);
	        curl_setopt($curl_request, CURLOPT_POST, 1);
	        curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
	        curl_setopt($curl_request, CURLOPT_HEADER, 1);
	        curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
	        curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
	        curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);

	        $jsonEncodedData = json_encode($parameters);

	        $post = array(
	             "method" => $method,
	             "input_type" => "JSON",
	             "response_type" => "JSON",
	             "rest_data" => $jsonEncodedData
	        );

	        curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
	        $result = curl_exec($curl_request);
	        curl_close($curl_request);

	        $result = explode("\r\n\r\n", $result, 2);
	        $response = json_decode($result[1]);
	        ob_end_flush();

	        return $response;
	    }
	    //login --------------------------------------------- 
	    $login_parameters = array(
	         "user_auth" => array(
	              "user_name" => $username2,
	              "password" => md5($password2),
	              "version" => "1"
	         ),
	         "application_name" => "RestTest",
	         "name_value_list" => array(),
	    );

	    $login_result = call1("login", $login_parameters, $url2);

	    //get session id
	    $session_id = $login_result->id;
	    $get_module_fields_parameters = array(
		    //Session id
		    "session" => $session_id,

		    //The name of the module from which to retrieve fields
		    'module_name' => $module2,

		    //List of specific fields
		    'fields' => array(),
		);

	    $get_module_fields_result = call1("get_module_fields", $get_module_fields_parameters, $url2);
	    $modulefield1= array();
		foreach($get_module_fields_result->module_fields as $data) { 
			$modulefield1[]=$data->name;
		}
		$select_module2="";
		//echo $size_variables;
		//print_r($get_module_fields_result);
		for($i=1;$i<$size_variables;$i++){
			$select_module2.="<div class='form-group'><select class='form-control'  id='select1module$i' style='height:40px;' name='select2module$i'>
			<option value=''>--Select Field--</option>";
			foreach($get_module_fields_result->module_fields as $data) {
				if($data->name!='id' && $data->name!='modified_by_name' && $data->name!='created_by_name' && $data->name!='assigned_user_name' &&$data->name!='created_by'){
					$select_module2.="<option value=$data->name >$data->name</option>";
				}
				//$select_module2.="<option value=$data->name >$data->name</option>";
			}
			$select_module2.="</select></div>";
		}
		$js1 = <<<YUO
		<html>
<head>
  	<script>
  		$(document).ready(function(){
  			var modified_by_name="#"+$("#modified_by_name").attr("name");
  			var created_by_name="#"+$("#created_by_name").attr("name");
  			var assigned_user_name="#"+$("#assigned_user_name").attr("name");
  			var created_by="#"+$("#created_by").attr("name");
  			$('#modified_by_name').hide();
  			$('#created_by_name').hide();
  			$('#assigned_user_name').hide();
  			$('#created_by').hide();
  			$(modified_by_name).hide();
  			$(created_by_name).hide();
  			$(assigned_user_name).hide();
  			$(created_by).hide();
  			$('#dialogSugar').hide();
            $('#dialogSuite').hide();

        $script_select
        $('#map_save').change(function(){
          var map_save=$('#map_save').val();
          if(map_save=='Yes'){
            $("#name_map").prop('required',true);
          }
          else{
            $("#name_map").prop('required',false);
          }
          
        });
		$('#back_transfer').click(function(){
					var url='$url';
					//alert(url);
					window.location.href = url;
				});
  		})

      
  	</script>
    
</head>
<body>
	<h2>Map Fields</h2>
	<div class="container" id="form-crm-details">
	    <div class="row">
	        <form action="index.php">
	            <div class="col-xs-6">
	                <div class="form-group">
	                	<div class="form-group">
	                    <label for="crm1url">CRM 1 URL</label>
	                    <input type="text" class="form-control" name="crm1url" id="crm1url" placeholder="From CRM URL" value="$crm1url" required readonly>
		                </div>
		                <div class="form-group">
		                    <label for="username1">CRM Username</label>
		                    <input type="text" class="form-control" name="username1" id="username1" placeholder="CRM Username" value="$username1" required readonly>
		                </div>
		                <div class="form-group">
		                    <label for="password">Password</label>
		                    <input type="password" class="form-control" name="password1" id="password1" placeholder="Password" value="$password1"  required readonly>
		                </div>
	                    <label for="crm1url">CRM 1 Selected Module</label>
	                    <input type="text" class="form-control" name="module1" id="module1" placeholder="Module1" value="$module1" required readonly>
	                    <h2>Fields List 1</h2>
	                    $select_module1
	                </div>
                  <div class="form-group">
                      <label for="map_save">Save the map? </label>
                      <select class='form-control' style="height:40px;" id='map_save' name='map_save'>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                      </select>

                  </div>
	                <button type="submit" class="btn btn-default">Submit</button>
	            </div>
	            <div class="col-xs-6">
	                <div class="form-group">
	                	<div class="form-group">
	                    <label for="crm2url">CRM 2 URL</label>
	                    <input type="text" class="form-control" name="crm2url" id="crm2url" placeholder="To CRM URL" value="$crm2url"  required readonly>
		                </div>
		                <div class="form-group">
		                    <label for="username2">CRM Username</label>
		                    <input type="text" class="form-control" name="username2" id="username2" placeholder="CRM Username" value="$username2" required readonly>
		                </div>
		                <div class="form-group">
		                    <label for="password">Password</label>
		                    <input type="password" class="form-control" name="password2" id="password2" placeholder="Password" value="$password2" required readonly>
		                </div>
	                    <label for="crm1url">CRM 2 Selected Module</label>
	                    <input type="text" class="form-control" name="module2" id="module2" placeholder="Module1" value="$module2" required readonly>
	                    <h2>Fields List 2</h2>
          						$select_module2
          						<input type="text" class="form-control" name="size" id="size" placeholder="size" style="display:none" value="$size_variables" required readonly>
                      </div class="form-group">
                      <label for="name_map">Name of Map</label>
                      <input type="text" class="form-control" name="name_map" id="name_map" style="height:40px;" placeholder="Name of Map" required>
                      $for_back_button
                      <input type="text" class="form-control" name="module" id="size" placeholder="size" style="display:none" value="srav_Mapping_Functionality" required readonly>
	                  <input type="text" class="form-control" name="action" id="size" placeholder="size" style="display:none" value="transferdata" required readonly>
                      </div>
	                </div>
	                
	            </div>
	        </form>
	    </div>
	</div>
</body>
</html>

YUO;
echo $js1;
	}

}
