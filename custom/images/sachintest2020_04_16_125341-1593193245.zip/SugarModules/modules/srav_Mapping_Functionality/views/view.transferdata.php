<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class ViewTransferdata extends ViewDetail {


	function ViewTransferdata(){
		parent::ViewDetail();
	}
	
	function display() {
		    global $db,$sugar_config;
		    $site_url=$sugar_config['site_url'];
			$map_save=$_REQUEST['map_save'];
			$name_map=$_REQUEST['name_map'];
			if($map_save=='Yes'){
				$server_url=$_SERVER['QUERY_STRING'];
				$map_save_url="/index.php?".str_replace("action=transferdata","action=mapvariables",$server_url);
				$id=create_guid();
				date_default_timezone_set('UTC');
				$date= date('Y-m-d H:i:s');
				$query_mapsave="insert into mapping_save (id,name,date_entered,date_modified,description,deleted) values ('$id','$name_map','$date','$date','$map_save_url','0')";
				$result_mapsave=$db->query($query_mapsave);
			}

		$crm1url       = $_REQUEST['crm1url'];
		$password1     = $_REQUEST['password1'];
		$username1     = $_REQUEST['username1'];
		$module1       = $_REQUEST['module1'];
		$crm2url       = $_REQUEST['crm2url'];
		$password2     = $_REQUEST['password2'];
		$username2     = $_REQUEST['username2'];
		$module2       = $_REQUEST['module2'];
		$url1          = $crm1url."/service/v4_1/rest.php";
		$url2          = $crm2url."/service/v4_1/rest.php";
		$select_fields = array();
		$set_fields    = array(); 
		function call($method, $parameters, $url1)
		{
		    ob_start();
		    $curl_request = curl_init();
		    
		    curl_setopt($curl_request, CURLOPT_URL, $url1);
		    curl_setopt($curl_request, CURLOPT_POST, 1);
		    curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
		    curl_setopt($curl_request, CURLOPT_HEADER, 1);
		    curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
		    curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
		    curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);
		    
		    $jsonEncodedData = json_encode($parameters);
		    
		    $post = array(
		        "method" => $method,
		        "input_type" => "JSON",
		        "response_type" => "JSON",
		        "rest_data" => $jsonEncodedData
		    );
		    
		    curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
		    $result = curl_exec($curl_request);
		    curl_close($curl_request);
		    
		    $result   = explode("\r\n\r\n", $result, 2);
		    $response = json_decode($result[1]);
		    ob_end_flush();
		    
		    return $response;
		}

		//login ----------------------------------------- 
		$login_parameters = array(
		    "user_auth" => array(
		        "user_name" => $username1,
		        "password" => md5($password1),
		        "version" => "1"
		    ),
		    "application_name" => "RestTest",
		    "name_value_list" => array()
		);

		$login_result = call("login", $login_parameters, $url1);
		$session_id   = $login_result->id;
		$size         = $_REQUEST['size'] - 1;
		for ($i = 1; $i <= $size; $i++) {
		    if (!empty($_REQUEST["select2module$i"])) {
		        if ($_REQUEST["select2module$i"] != 'deleted') {
		            if($i=='2' && $module1=='Notes'){
		                $j='0';
		                $select_fields[] = $_REQUEST["select1module$j"];
		            }
		            else{
		                $select_fields[] = $_REQUEST["select1module$i"];
		            }
		            
		            $set_fields[]    = $_REQUEST["select2module$i"];
		            //echo $_REQUEST["select2module$i"];
		            //exit;
		        }
		    }
		    
		}

		// print_r($select_fields);
		// print_r($set_fields);  

		//exit;
		//get list of records --------------------------------
		$get_entry_list_parameters = array(
		    
		    //session id
		    'session' => $session_id,
		    
		    //The name of the module from which to retrieve records
		    'module_name' => $module1,
		    
		    //The SQL WHERE clause without the word "where".
		    //this is for searching
		    // 'query' => "abc12_faqs.assigned_user_id='1'",
		    // 'query' => "abc12_faqs.assigned_user_id=''",
		    'query'=>"",
		    
		    'order_by' => "",
		    
		    //The record offset from which to start.
		    'offset' => '0',
		    
		    'select_fields' => $select_fields,
		    'link_name_to_fields_array' => array(),
		    'max_results' => '1000',
		    //To exclude deleted records
		    'deleted' => '0',
		    
		    //If only records marked as favorites should be returned.
		    'Favorites' => false
		);

		$get_entry_list_result = call('get_entry_list', $get_entry_list_parameters, $url1);
		// echo '<pre>';
		// print_r($get_entry_list_result);
		// echo '</pre>';

		function call1($method, $parameters, $url2)
		{
		    ob_start();
		    $curl_request = curl_init();
		    
		    curl_setopt($curl_request, CURLOPT_URL, $url2);
		    curl_setopt($curl_request, CURLOPT_POST, 1);
		    curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
		    curl_setopt($curl_request, CURLOPT_HEADER, 1);
		    curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
		    curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
		    curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);
		    
		    $jsonEncodedData = json_encode($parameters);
		    
		    $post = array(
		        "method" => $method,
		        "input_type" => "JSON",
		        "response_type" => "JSON",
		        "rest_data" => $jsonEncodedData
		    );
		    
		    curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
		    $result = curl_exec($curl_request);
		    curl_close($curl_request);
		    
		    $result   = explode("\r\n\r\n", $result, 2);
		    $response = json_decode($result[1]);
		    ob_end_flush();
		    
		    return $response;
		}

		//login ----------------------------------------- 
		$login_parameters = array(
		    "user_auth" => array(
		        "user_name" => $username2,
		        "password" => md5($password2),
		        "version" => "1"
		    ),
		    "application_name" => "RestTest",
		    "name_value_list" => array()
		);

		$login_result = call1("login", $login_parameters, $url2);
		$session_id   = $login_result->id;
		//echo $session_id;
		$size_list    = sizeof($get_entry_list_result->entry_list);
		//echo $size_list;
		for ($i = 0; $i < $size_list; $i++) {
		    $set_final_list = array();
		    $list           = $get_entry_list_result->entry_list[$i]->name_value_list;
		    
		    
		    //echo "<pre>";
		    //print_r($list);
		    $array     = json_decode(json_encode($list), True);
		    $set_array = array_values($array);
		    //print_r($set_array);
		    //print_r($set_fields);
		    for ($j = 0; $j < count($set_fields); $j++) {
		        $set_field       = $set_fields[$j];
		        $set_array_final = array();
		        $set_array_one   = $set_array[$j];
		        //print_r($set_array_one);
		        foreach ($set_array_one as $key => $value) {
		            $set_array_one['name'] = $set_field;
		            
		        }
		        $set_final_list[] = $set_array_one;
		        
		    }
		    
		    $set_entry_parameters = array(
		        //session id
		        "session" => $session_id,
		        
		        //The name of the module from which to retrieve records.
		        "module_name" => $module2,
		        
		        //Record attributes
		        "name_value_list" => $set_final_list,
		    );
		    //echo "<pre>";
		    //print_r($set_entry_parameters);
		    $set_entry_result     = call1("set_entry", $set_entry_parameters, $url2);
		    //print_r($set_entry_result);
		    //exit;
		    
		}
		$js1 = <<<YUO
 <html>
<head>
    <script>
        $(document).ready(function(){
            $('#dialogSugar').hide();
            $('#dialogSuite').hide();
            
        })
    </script>
</head>
<body>
    <div class="container">
        <h2>Data Transferred successfully</h2>
        <a href="index.php?module=srav_Mapping_Functionality" class="btn btn-info" role="button">Transfer Data Again?</a>
    </div>
</body>
</html>

YUO;
echo $js1;

	}

}

?>