<?php 
 // created: 2020-04-16 12:53:38
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';

?>
