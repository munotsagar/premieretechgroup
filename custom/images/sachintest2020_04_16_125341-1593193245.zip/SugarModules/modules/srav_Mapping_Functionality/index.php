<?php
global $db,$sugar_config,$current_user;
$site_url=$sugar_config['site_url'];
$username="mapping_functionality_user";
$password="mapping_functionality_user";
$db_password=md5($password);
$id=create_guid();
date_default_timezone_set('UTC');
$date= date('Y-m-d H:i:s');
$query_mapping_user_select="select count(*) as count from users where user_name='$username' and deleted='0'";
$result_mapping_user_select=$db->query($query_mapping_user_select);
$row_mapping_user_select=$db->fetchByAssoc($result_mapping_user_select);
$count=$row_mapping_user_select['count'];
$query_mapping_save="CREATE TABLE IF NOT EXISTS `mapping_save` (
  `id` char(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `description` text,
  `deleted` tinyint(1) DEFAULT '0')";
$result_mapping_save=$db->query($query_mapping_save);
if($count=='0'){
  $query_user_insert="insert into users (id,user_name,user_hash,sugar_login,first_name,last_name,is_admin,date_modified,date_entered,modified_user_id,created_by,title,employee_status,show_on_employees,deleted,status) values ('$id','$username','$db_password','1','$username','$username','1','$date','$date','1','1','Mapping Functionality User','Active','1','0','Active')";
  $result_user_insert=$db->query($query_user_insert);
}
$query_map_data="select id,name,description from mapping_save where deleted='0'";
$result_map_data=$db->query($query_map_data);
$map_div='0';
$select_map="<select class='form-control' style='width:200px;' id='select_map' name='select_map'>
    <option value=''>--Select Saved Map--</option>";

while($row_map_data=$db->fetchByAssoc($result_map_data)){
  $map_div++;
  $map_id=$row_map_data['id'];
  $map_name=$row_map_data['name'];
  $map_description=$row_map_data['description'];
  $value=$map_id.'$*%_%_%*$'.$map_description;
  $select_map.="<option value=$value >$map_name</option>";
}
$select_map.='</select>';

//credentials list
$url1 = "http://crm.ideadunes.com/webapptestcrm/service/v4_1/rest.php";
$username1="webapp-api@ideadunes.com";
$password1="APps@0605";
      //function to make cURL request
      function call($method, $parameters, $url1)
      {
          ob_start();
          $curl_request = curl_init();

          curl_setopt($curl_request, CURLOPT_URL, $url1);
          curl_setopt($curl_request, CURLOPT_POST, 1);
          curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
          curl_setopt($curl_request, CURLOPT_HEADER, 1);
          curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
          curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);

          $jsonEncodedData = json_encode($parameters);

          $post = array(
               "method" => $method,
               "input_type" => "JSON",
               "response_type" => "JSON",
               "rest_data" => $jsonEncodedData
          );

          curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
          $result = curl_exec($curl_request);
          curl_close($curl_request);

          $result = explode("\r\n\r\n", $result, 2);
          $response = json_decode($result[1]);
          ob_end_flush();

          return $response;
      }
      //login --------------------------------------------- 
      $login_parameters = array(
           "user_auth" => array(
                "user_name" => $username1,
                "password" => md5($password1),
                "version" => "1"
           ),
           "application_name" => "RestTest",
           "name_value_list" => array(),
      );

      $login_result = call("login", $login_parameters, $url1);

      //get session id
      $session_id = $login_result->id;
      $get_entry_list_parameters = array(
        
        //session id
        'session' => $session_id,
        
        //The name of the module from which to retrieve records
        'module_name' => 'abc12_Credentials',
        
        //The SQL WHERE clause without the word "where".
        //this is for searching
        // 'query' => "abc12_faqs.assigned_user_id='1'",
        // 'query' => "abc12_faqs.assigned_user_id=''",
        'query'=>"abc12_credentials_cstm.status_c='Active'",
        
        'order_by' => "",
        
        //The record offset from which to start.
        'offset' => '0',
        
        'select_fields' => array('id','name','password_c','project_url_c'),
        'link_name_to_fields_array' => array(),
        'max_results' => '1000',
        //To exclude deleted records
        'deleted' => '0',
        
        //If only records marked as favorites should be returned.
        'Favorites' => false
    );

    $get_entry_list_result = call('get_entry_list', $get_entry_list_parameters, $url1);

$size=sizeof($get_entry_list_result->entry_list);
$existing_select="<div class='form-group' id='div_existing_credentials'><label for='existing_select'>Existing Credentials</label><select class='form-control'  id='existing_credentials' style='height:40px;' name='existing_credentials'>
      <option value=''>--Select Existing Credentials--</option>";
for($i=0;$i<$size;$i++){
  $id=$get_entry_list_result->entry_list[$i]->name_value_list->id->value;
  $name=$get_entry_list_result->entry_list[$i]->name_value_list->name->value;
  $password_credentials=$get_entry_list_result->entry_list[$i]->name_value_list->password_c->value;
  $project_url=$get_entry_list_result->entry_list[$i]->name_value_list->project_url_c->value;
  //echo $project_url;
  $value=$id.'%_%'.$project_url.'%_%'.$name.'%_%'.$password_credentials;

  $existing_select.="<option value=$value >$project_url</option>";
}
$existing_select.="</select></div>";
$js1 = <<<YUO
 
    <script>
        $(document).ready(function(){
          $("#existing_credentials").prop("disabled", true);
            var i='$map_div';
            if(i<='0'){
                $('#mapping_div').hide();
            }
            else{
              $('#mapping_div').show();
            }
            $('#massassign_form').hide();
            $('#dialogSugar').hide();
            $('#dialogSuite').hide();
            $('#get_map').hide();
            $('#delete_map').hide();
            var map_select=$('#select_map').val();
            if(map_select!=''){
                  $('#row').hide();
                  $('#get_map').show();
                  //$('#delete_map').show();
                  
                  
              }else{
                $('#row').show();
                $('#get_map').hide();
                $('#delete_map').hide();
                
              }
            $('#same_crm').change(function() {
              if($(this).is(":checked")) {
                  document.getElementById('crm2url').value=document.getElementById('crm1url').value;
                  document.getElementById('username2').value=document.getElementById('username1').value;
                  document.getElementById('password2').value=document.getElementById('password1').value;
              }
              else{
                document.getElementById('crm2url').value="";
                document.getElementById('username2').value="";
                document.getElementById('password2').value="";
              }
                 
            });
            var url='';
            $('#select_map').change(function(){
              var map_select=$('#select_map').val();
              if(map_select!=''){
                  $('#row').hide();
                  $('#get_map').show();
                  $('#delete_map').show();
                  
                  
              }else{
                $('#row').show();
                $('#get_map').hide();
                $('#delete_map').hide();
                
              }

            });
            $('#get_map').click(function(){
                var map_select=$('#select_map').val();
                var arr = map_select.split('$*%_%_%*$');
                  var id=arr['0'];
                  var siteurl='$site_url';
                  var url=siteurl+arr['1'];
                  window.location.href = url;
            });
            $('#delete_map').click(function(){
                var map_select=$('#select_map').val();
                var arr = map_select.split('$*%_%_%*$');
                var id=arr['0'];
                  $.ajax({
                        url: 'deletemap.php',
                        type:'GET',
                        async: false,
                        data:{
                            id:id,
                        },
                    }).done(function(data){
                      var siteurl='$site_url';
                      var url=siteurl+"/index.php?module=srav_Mapping_Functionality";
                      window.location.href = url;
                    });

            });
            $("input[name='credentials_2']").click(function() {
                credentials_2 = this.value;
                if(credentials_2=='existing'){
                  $("#existing_credentials").prop("disabled", false);
                }
                else{
                  $("#existing_credentials").prop("disabled", true);
                }
            });
            $('#existing_credentials').change(function(){
               var value_existing=$('#existing_credentials').val();
               if(value_existing==''){
                  $("#crm2url").prop("readonly", false);
                  $("#username2").prop("readonly", false);
                  $("#password2").prop("readonly", false);
               }
               else{
                  var arr = value_existing.split('%_%');
                  var id=arr['0'];
                  var projecturl=arr['1'];
                  var username=arr['2'];
                  var password=arr['3'];
                  $("#crm2url").val(projecturl);
                  $("#username2").val(username);
                  $("#password2").val(password);
                  $("#crm2url").prop("readonly", true);
                  $("#username2").prop("readonly", true);
                  $("#password2").prop("readonly", true);

               }
            });
        })
    </script>
    
  <div class="container" id="form-crm-details">
        <div class="row" id='mapping_div'>
          <div class="form-group">
              <label for="map_select">Select Saved Map</label>
              $select_map
          </div>
           </div class="form-group">
                <button type="button" id='get_map' class="btn btn-success">Get Map</button>
                <button type="button" id='delete_map' class="btn btn-danger">Delete Map</button>
            </div>
          </div>
      <div class="form-group" id='row'>

          <form action="index.php">
              <div class="col-xs-6">
                  
                   <div class="form-group">
                  <label for="usertype1">User Type</label><br>
                  <label class="radio-inline">
                  <input type="radio" value='existing' class="credentials_2" name="credentials_2">Existing Credentials
                  </label>
                  <label class="radio-inline">
                      <input type="radio" value='new' class="credentials_2" name="credentials_2" checked>New Credentials
                  </label>
               </div>
                  <div class="form-group">
                      <label for="crm1url">CRM 1 URL</label>
                      <input type="text" class="form-control" name="crm1url" id="crm1url" placeholder="From CRM URL" value="$site_url" required readonly>
                  </div>
                  <div class="form-group">
                      <label for="username1">CRM Username</label>
                      <input type="text" class="form-control" name="username1" id="username1" placeholder="CRM Username" value="$username" required readonly>
                  </div>
                  <div class="form-group">
                      <label for="password">Password</label>
                      <input type="password" class="form-control" name="password1" id="password1" placeholder="Password" value="$password"  required readonly>
                  </div>
                  <div class="form-group">
                  <label>Same CRM</label>
                  <input type="checkbox" id='same_crm'>
                  </div>
          
                  <button type="submit" class="btn btn-default">Submit</button>
              </div>
              <div class="col-xs-6">
                  $existing_select
                  <div class="form-group">
                      <label for="crm2url">CRM 2 URL</label>
                      <input type="text" class="form-control" name="crm2url" id="crm2url" placeholder="To CRM URL"  required>
                  </div>
                  <div class="form-group">
                      <label for="username2">CRM Username</label>
                      <input type="text" class="form-control" name="username2" id="username2" placeholder="CRM Username"  required>
                  </div>
                  <div class="form-group">
                      <label for="password">Password</label>
                      <input type="password" class="form-control" name="password2" id="password2" placeholder="Password"  required>
                  </div>
                  <input type="text" class="form-control" name="module" id="size" placeholder="size" style="display:none" value="srav_Mapping_Functionality" required readonly>
                  <input type="text" class="form-control" name="action" id="size" placeholder="size" style="display:none" value="modulelist" required readonly>
                    </div>
          </form>
      </div>
  </div>

YUO;
echo $js1; 
?>