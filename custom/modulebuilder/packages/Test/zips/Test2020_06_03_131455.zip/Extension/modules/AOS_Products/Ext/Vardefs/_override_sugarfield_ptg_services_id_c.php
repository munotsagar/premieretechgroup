<?php
 // created: 2020-06-02 10:30:54
$dictionary['AOS_Products']['fields']['ptg_services_id_c']['inline_edit']=1;

 ?>