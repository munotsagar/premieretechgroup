<?php
 // created: 2020-06-03 10:42:39
$dictionary['User']['fields']['currency_id']['inline_edit']=1;

 ?>