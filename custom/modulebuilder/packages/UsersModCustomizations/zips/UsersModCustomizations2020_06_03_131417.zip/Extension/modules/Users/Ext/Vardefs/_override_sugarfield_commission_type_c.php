<?php
 // created: 2020-06-03 10:40:13
$dictionary['User']['fields']['commission_type_c']['inline_edit']='1';
$dictionary['User']['fields']['commission_type_c']['labelValue']='Commission Type';

 ?>