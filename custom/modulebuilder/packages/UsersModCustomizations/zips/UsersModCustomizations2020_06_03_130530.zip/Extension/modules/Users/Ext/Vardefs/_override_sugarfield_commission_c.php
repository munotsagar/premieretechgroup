<?php
 // created: 2020-06-03 11:09:20
$dictionary['User']['fields']['commission_c']['inline_edit']='1';
$dictionary['User']['fields']['commission_c']['labelValue']='Commission';

 ?>