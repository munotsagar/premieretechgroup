<?php 
$app_list_strings['commission_type_list'] = array (
  'Amount' => 'Amount',
  'Percentage' => 'Percentage',
);$app_list_strings['user_category_list'] = array (
  'Employee' => 'Employee',
  'Vendor' => 'Vendor',
  'Manager' => 'Manager',
  'Super_User' => 'Super User',
);