<?php 
 // created: 2020-06-03 13:04:04
$mod_strings['LBL_COMMISSION_TYPE'] = 'Commission Type';
$mod_strings['LBL_COMMISSION'] = 'Commission';
$mod_strings['LBL_USER_CATEGORY'] = 'User Category';

?>
