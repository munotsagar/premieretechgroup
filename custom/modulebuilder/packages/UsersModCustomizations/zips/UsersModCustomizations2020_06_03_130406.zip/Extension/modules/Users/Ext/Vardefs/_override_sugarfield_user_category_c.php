<?php
 // created: 2020-06-03 11:13:00
$dictionary['User']['fields']['user_category_c']['inline_edit']='1';
$dictionary['User']['fields']['user_category_c']['labelValue']='User Category';

 ?>