<?php
 // created: 2020-06-02 13:23:25
$dictionary['ptg_VoiceServiceRequest']['fields']['country_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['country_c']['labelValue']='Country';

 ?>