<?php
 // created: 2020-06-02 13:15:46
$dictionary['ptg_VoiceServiceRequest']['fields']['local_phone_number_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['local_phone_number_c']['labelValue']='Local Phone Number';

 ?>