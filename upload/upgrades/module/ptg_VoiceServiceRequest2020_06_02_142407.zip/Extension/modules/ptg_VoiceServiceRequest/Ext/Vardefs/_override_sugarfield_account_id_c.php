<?php
 // created: 2020-06-02 13:11:36
$dictionary['ptg_VoiceServiceRequest']['fields']['account_id_c']['inline_edit']=1;

 ?>