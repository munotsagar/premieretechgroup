<?php
 // created: 2020-06-02 13:14:21
$dictionary['ptg_VoiceServiceRequest']['fields']['customer_name_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['customer_name_c']['labelValue']='Customer Name';

 ?>