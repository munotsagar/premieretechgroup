<?php
 // created: 2020-06-02 13:25:14
$dictionary['ptg_VoiceServiceRequest']['fields']['select_product_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['select_product_c']['labelValue']='Select Products';

 ?>