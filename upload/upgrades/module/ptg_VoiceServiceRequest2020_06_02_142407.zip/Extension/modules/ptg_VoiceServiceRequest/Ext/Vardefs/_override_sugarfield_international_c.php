<?php
 // created: 2020-06-02 13:40:30
$dictionary['ptg_VoiceServiceRequest']['fields']['international_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['international_c']['labelValue']='International';

 ?>