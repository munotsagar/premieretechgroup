<?php
 // created: 2020-06-02 14:20:16
$dictionary['ptg_VoiceServiceRequest']['fields']['comment_additional_info_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['comment_additional_info_c']['labelValue']='Comment & Additional Information';

 ?>