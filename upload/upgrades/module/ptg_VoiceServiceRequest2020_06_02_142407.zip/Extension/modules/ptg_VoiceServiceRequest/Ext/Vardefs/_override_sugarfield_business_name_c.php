<?php
 // created: 2020-06-02 13:13:20
$dictionary['ptg_VoiceServiceRequest']['fields']['business_name_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['business_name_c']['labelValue']='Business Name';

 ?>