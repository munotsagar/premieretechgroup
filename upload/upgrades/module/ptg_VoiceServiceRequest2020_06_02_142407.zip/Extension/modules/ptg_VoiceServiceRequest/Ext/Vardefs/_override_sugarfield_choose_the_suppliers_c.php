<?php
 // created: 2020-06-02 13:50:22
$dictionary['ptg_VoiceServiceRequest']['fields']['choose_the_suppliers_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['choose_the_suppliers_c']['labelValue']='Choose the Suppliers';

 ?>