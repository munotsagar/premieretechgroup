<?php
 // created: 2020-06-02 13:25:14
$dictionary['ptg_VoiceServiceRequest']['fields']['aos_products_id_c']['inline_edit']=1;

 ?>