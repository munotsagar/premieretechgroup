<?php
 // created: 2020-06-02 13:17:09
$dictionary['ptg_VoiceServiceRequest']['fields']['main_address_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['main_address_c']['labelValue']='Main Address';

 ?>