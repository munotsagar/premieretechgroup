<?php
 // created: 2020-06-02 13:18:22
$dictionary['ptg_VoiceServiceRequest']['fields']['city_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['city_c']['labelValue']='City';

 ?>