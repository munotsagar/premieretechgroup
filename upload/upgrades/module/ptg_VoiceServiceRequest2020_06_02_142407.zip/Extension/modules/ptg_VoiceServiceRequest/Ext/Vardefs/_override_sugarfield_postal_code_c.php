<?php
 // created: 2020-06-02 13:22:12
$dictionary['ptg_VoiceServiceRequest']['fields']['postal_code_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['postal_code_c']['labelValue']='Postal Code';

 ?>