<?php
 // created: 2020-06-02 13:57:52
$dictionary['ptg_VoiceServiceRequest']['fields']['suppliers_to_quote_c']['inline_edit']='1';
$dictionary['ptg_VoiceServiceRequest']['fields']['suppliers_to_quote_c']['labelValue']='Suppliers to Quote';

 ?>