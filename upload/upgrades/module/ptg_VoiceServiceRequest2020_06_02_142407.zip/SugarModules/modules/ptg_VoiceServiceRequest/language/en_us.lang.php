<?php 
 // created: 2020-06-02 14:24:07
$mod_strings['LBL_CUSTOMER_NAME_ACCOUNT_ID'] = 'Customer Name (related Account ID)';
$mod_strings['LBL_CUSTOMER_NAME'] = 'Customer Name';
$mod_strings['LBL_BUSINESS_NAME'] = 'Business Name';
$mod_strings['LBL_LOCAL_PHONE_NUMBER'] = 'Local Phone Number';
$mod_strings['LBL_MAIN_ADDRESS'] = 'Main Address';
$mod_strings['LBL_CITY'] = 'City';
$mod_strings['LBL_STATE'] = 'State';
$mod_strings['LBL_POSTAL_CODE'] = 'Postal Code';
$mod_strings['LBL_COUNTRY'] = 'Country';
$mod_strings['LBL_SELECT_PRODUCT_AOS_PRODUCTS_ID'] = 'Select Products (related  ID)';
$mod_strings['LBL_SELECT_PRODUCT'] = 'Select Products';
$mod_strings['LBL_TERMS_TO_QUOTE'] = 'Terms to Quote';
$mod_strings['LBL_INTERNATIONAL'] = 'International';
$mod_strings['LBL_CHOOSE_THE_SUPPLIERS'] = 'Choose the Suppliers';
$mod_strings['LBL_SUPPLIERS_TO_QUOTE'] = 'Suppliers to Quote';
$mod_strings['LBL_COMMENT_ADDITIONAL_INFO'] = 'Comment & Additional Information';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Customer Information';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Products';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Quote Information';
$mod_strings['LBL_EDITVIEW_PANEL4'] = 'Additional Information';

?>
