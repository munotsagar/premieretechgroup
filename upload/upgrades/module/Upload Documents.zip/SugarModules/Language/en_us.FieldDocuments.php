<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['fieldTypes']['documents'] = 'Documents';

 ?>