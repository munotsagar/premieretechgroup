<?php
    require_once('modules/Configurator/Configurator.php');
    $cfg = new Configurator();

    /** Your setting to save in config_override.php :: By NITIN SHUKLA 25MAY2018*/
    $cfg->config['image_path'] = 'custom/images/';
    $cfg->handleOverride();
?>