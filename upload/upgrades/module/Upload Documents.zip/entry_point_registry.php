<?php
$entry_point_registry['multiImage'] = array('file' => 'custom/drag_crm/upload.php', 'auth' => '1');
$entry_point_registry['multiImageDelete'] = array('file' => 'custom/drag_crm/delete.php', 'auth' => '1');
?>