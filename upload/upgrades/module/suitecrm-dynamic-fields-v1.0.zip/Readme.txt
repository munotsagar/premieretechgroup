*******************************************************************************
* Suitecrm Dynamic Fields V1.0                                                *
* Developed by The Midland Web Company www.midlandwebcompany.com              *
* 
*******************************************************************************

Thank you for downloading our module. This module allows you to add as many fields as you
need to existing fields, for example if you need to add more than one mobile number, website, fax 

number, Opportunity Name. You can add an unlimited amount of fields via the edit view in any module 

like accounts, contacts.


Installation:

1) Navigate to your admin area within suitecrm.
2) Click on module loader.
3) Click on browse.
4) Open your suitecrm-dynamic-fields-v1.0 folder.
5) Double click the suitecrm-dynamic-fields-v1.0.zip folder then click upload
6) The module will be loaded into the module area below the browse button.
7) Then click Install.

That's It all done now time to take it for a test drive.
Please look at the following youtube video to see how you install and how to use the module.

If your having problems with the plugin please get in touch at midlandwebcompany.com

Thanks
Aiden