<?php
/* *********************************************************************************
 * Developed by: Midland Web Company www.midlandwebcompany.com*
 ***********************************************************************************/
//WARNING: The contents of this file are auto-generated



$mod_strings['LBL_DF_DYNAMIC_FIELD_HEADER'] = 'Dynamic Fields';
$mod_strings['LBL_DF_DYNAMIC_FIELD_TITLE'] = 'Dynamic Fields';
$mod_strings['LBL_DF_DYNAMIC_FIELD_DESC'] = 'Open this, select module and a fild to make dynamic.';

?>