<?php
 // created: 2020-06-02 12:23:29
$dictionary['AOS_Products']['fields']['service_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['service_c']['labelValue']='Service';

 ?>