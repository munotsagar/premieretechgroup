<?php 
 // created: 2020-06-02 12:29:59
$mod_strings['LBL_SERVICE_PTG_SERVICES_ID'] = 'Service (related  ID)';
$mod_strings['LBL_SERVICE'] = 'Service';

?>
